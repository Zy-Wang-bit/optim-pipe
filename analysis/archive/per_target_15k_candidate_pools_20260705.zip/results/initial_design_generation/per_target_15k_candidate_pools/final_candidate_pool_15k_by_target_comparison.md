# Per-target 15K candidate draft comparison

Verdict: `PASS_PER_TARGET_15K_DRAFTS_BUILT__FINAL_ORDER_LOCKED`.

Each antibody now has its own 15K pre-synthesis candidate draft. These are candidate pools, not final order lists.

| target | selected_count | main_count | control_anchor_count | top_seed | top_seed_fraction | top_cluster_fraction | four_mut_fraction | local_expansion_fraction | seed_only_fraction | neutral_boundary_or_high_risk_fraction | sdAb_complex_diagnostic_required_count | AG102H_AV105H_main_count | glycan_low_risk_claim_count | verdict | reasons |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Ab_1E62 | 15000 | 14980 | 20 | LK24H;LQ35H | 0.216600 | 0.027000 | 0.583667 | 0.633333 | 0.079867 | 0.245933 |  |  | 0 | PASS | all_per_target_15k_gates_pass |
| Ab_sdAb | 15000 | 14980 | 20 | AQ100H | 0.300000 | 0.029133 | 0.045267 | 0.381067 | 0.082733 | 0.040067 | 15000 | 0 | 0 | PASS | all_per_target_15k_gates_pass |

## Output files

- `final_candidate_pool_1E62_15k_draft.csv`
- `final_candidate_pool_sdAb_15k_draft.csv`
- `final_candidate_pool_1E62_15k_audit.md`
- `final_candidate_pool_sdAb_15k_audit.md`
- `control_anchor_15k_plan.md`

## Locked items

- Direct synthesis / wet-lab order generation remains locked.
- sdAb remains secondary / complex-diagnostic-required, not structure-confirmed.
- Glycan remains unchecked, not low risk.
