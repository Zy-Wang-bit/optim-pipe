# 1E62 per-target 15K candidate draft audit

Verdict: `PASS`.

This is a pre-synthesis candidate-pool draft, not a final order list.
No new variants, AF3, SimpleFold, PyRosetta, FoldX, MD, or glycan modeling were run.

## Summary

| target | selected_count | main_count | control_anchor_count | canonical_duplicate_count | sequence_duplicate_count | variant_id_duplicate_count | hard_failure_count | top_seed | top_seed_count | top_seed_fraction | top_cluster | top_cluster_count | top_cluster_fraction | four_mut_count | four_mut_fraction | local_expansion_count | local_expansion_fraction | seed_only_count | seed_only_fraction | neutral_boundary_or_high_risk_count | neutral_boundary_or_high_risk_fraction | glycan_low_risk_claim_count | sdAb_complex_diagnostic_required_count | AG102H_AV105H_main_count | AY111H_containing_count | AY111H_containing_fraction | reasons |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Ab_1E62 | 15000 | 14980 | 20 | 0 | 0 | 0 | 0 | LK24H;LQ35H | 3249 | 0.216600 | Ab_1E62_hjc_00008 | 405 | 0.027000 | 8755 | 0.583667 | 9500 | 0.633333 | 1198 | 0.079867 | 3689 | 0.245933 | 0 |  |  |  |  | all_per_target_15k_gates_pass |

## Evidence class distribution

| candidate_type | evidence_class | quality_tier | template_match_tier | count |
| --- | --- | --- | --- | --- |
| main_candidate | active_primary_backfill_template | supported | local_expansion_B | 3427 |
| main_candidate | active_primary_template | neutral_boundary_or_high_risk | B_medium | 2680 |
| main_candidate | active_primary_template | supported | local_expansion_A | 2349 |
| main_candidate | active_primary_backfill_template | supported | local_expansion_A | 1902 |
| main_candidate | active_primary_template | supported | local_expansion_B | 1822 |
| main_candidate | active_primary_template | high_support | C_seed_only | 887 |
| main_candidate | active_primary_backfill_template | neutral_boundary_or_high_risk | B_medium | 848 |
| main_candidate | active_primary_template | high_support | B_medium | 281 |
| main_candidate | active_primary_backfill_template | high_support | C_seed_only | 214 |
| main_candidate | active_primary_backfill_template | high_support | B_medium | 180 |
| main_candidate | active_primary_backfill_template | neutral_boundary_or_high_risk | A_strong | 76 |
| main_candidate | active_primary_template | neutral_boundary_or_high_risk | A_strong | 67 |
| main_candidate | limited_boundary_template | high_support | B_medium | 64 |
| main_candidate | active_primary_template | supported | C_seed_only | 56 |
| main_candidate | active_primary_backfill_template | supported | C_seed_only | 41 |
| main_candidate | active_primary_backfill_template | bank_reviewed | template_seed | 24 |
| control_anchor | control_anchor | control_anchor |  | 20 |
| main_candidate | limited_boundary_template | neutral_boundary_or_high_risk | A_strong | 18 |
| main_candidate | active_primary_template | bank_reviewed | template_seed | 16 |
| main_candidate | active_primary_template | supported | B_medium | 14 |
| main_candidate | active_primary_backfill_template | supported | B_medium | 8 |
| main_candidate | limited_boundary_template | bank_reviewed | template_seed | 6 |

## Source distribution

| candidate_type | source_pool | quality_tier | template_match_tier | count |
| --- | --- | --- | --- | --- |
| main_candidate | constrained_local_expansion_v2 | supported | local_expansion_A | 4251 |
| main_candidate | constrained_low_frequency_seed_local_expansion_v2 | supported | local_expansion_B | 3152 |
| main_candidate | constrained_local_expansion_v2 | supported | local_expansion_B | 2097 |
| main_candidate | tier2_candidate_snapshot | neutral_boundary_or_high_risk | B_medium | 2006 |
| main_candidate | tier1_ranked_production_pool | neutral_boundary_or_high_risk | B_medium | 1522 |
| main_candidate | tier1_ranked_production_pool | high_support | C_seed_only | 603 |
| main_candidate | tier2_candidate_snapshot | high_support | C_seed_only | 463 |
| main_candidate | tier2_candidate_snapshot | high_support | B_medium | 356 |
| main_candidate | tier1_ranked_production_pool | high_support | B_medium | 105 |
| main_candidate | tier1_ranked_production_pool | supported | C_seed_only | 97 |
| main_candidate | tier2_candidate_snapshot | neutral_boundary_or_high_risk | A_strong | 92 |
| main_candidate | tier1_ranked_production_pool | neutral_boundary_or_high_risk | A_strong | 69 |
| main_candidate | stage2a_candidate_list | high_support | B_medium | 64 |
| main_candidate | tier2_candidate_bank | bank_reviewed | template_seed | 46 |
| main_candidate | stage2a_candidate_list | high_support | C_seed_only | 35 |
| control_anchor | control_anchor_panel | control_anchor |  | 20 |
| main_candidate | stage2a_candidate_list | supported | B_medium | 18 |
| main_candidate | tier1_ranked_production_pool | supported | B_medium | 4 |

## Mutation count distribution

| mutation_count | count |
| --- | --- |
| 4 | 8755 |
| 3 | 6236 |
| 1 | 8 |
| 0 | 1 |

## Seed distribution

| his_seed_set | count | fraction |
| --- | --- | --- |
| LK24H;LQ35H | 3249 | 0.216600 |
| LK24H;LY38H | 3023 | 0.201533 |
| LY31H;LQ35H | 2649 | 0.176600 |
| LK24H;LY31H | 2078 | 0.138533 |
| LQ35H;LY38H | 829 | 0.055267 |
| LS33H;LQ35H | 156 | 0.010400 |
| LS28H;LS33H | 147 | 0.009800 |
| LY31H;LD34H | 147 | 0.009800 |
| LS33H;LD34H | 145 | 0.009667 |
| LS26H;LQ35H | 145 | 0.009667 |
| LS26H;LY38H | 143 | 0.009533 |
| LS28H;LY38H | 143 | 0.009533 |
| LS26H;LY31H | 142 | 0.009467 |
| LS28H;LY31H | 140 | 0.009333 |
| LS26H;LS28H | 139 | 0.009267 |
| LK24H;LD34H | 138 | 0.009200 |
| LS28H;LD34H | 137 | 0.009133 |
| LK24H;LS26H | 136 | 0.009067 |
| LS26H;LS33H | 136 | 0.009067 |
| LK24H;LS28H | 136 | 0.009067 |

## Cluster distribution

| near_duplicate_cluster_id | count | fraction |
| --- | --- | --- |
| Ab_1E62_hjc_00008 | 405 | 0.027000 |
| Ab_1E62_hjc_00019 | 379 | 0.025267 |
| Ab_1E62_hjc_00014 | 366 | 0.024400 |
| Ab_1E62_hjc_00003 | 362 | 0.024133 |
| Ab_1E62_hjc_00028 | 339 | 0.022600 |
| Ab_1E62_lex_00a1ade24dd6 | 60 | 0.004000 |
| Ab_1E62_lex_497a41f0757f | 60 | 0.004000 |
| Ab_1E62_lex_b784aea80d76 | 58 | 0.003867 |
| Ab_1E62_lex_442a67651305 | 58 | 0.003867 |
| Ab_1E62_lex_a144cc54517c | 57 | 0.003800 |
| Ab_1E62_lex_a1ed410abc5c | 57 | 0.003800 |
| Ab_1E62_lex_78da6851e97a | 56 | 0.003733 |
| Ab_1E62_lex_8cbf0eb6b4ef | 56 | 0.003733 |
| Ab_1E62_lex_913bd5144242 | 56 | 0.003733 |
| Ab_1E62_lex_39ffe0487ecd | 56 | 0.003733 |
| Ab_1E62_lex_a0a48c6f9824 | 56 | 0.003733 |
| Ab_1E62_lex_e8eabc7ba14d | 56 | 0.003733 |
| Ab_1E62_lex_fd1fea05bcbb | 56 | 0.003733 |
| Ab_1E62_lex_e0daed8c6d54 | 56 | 0.003733 |
| Ab_1E62_lex_6f159876adad | 56 | 0.003733 |

## Rejection / cap pressure summary

| reject_reason | count |
| --- | --- |
| local_expansion_cap_full | 3679 |
| duplicate_with_control | 9 |

## Conservative labels

- Glycan remains unchecked; no low-risk glycan claim is made.
- Manual review is required before final wet-lab order generation.
