# sdAb per-target 15K candidate draft audit

Verdict: `PASS`.

This is a pre-synthesis candidate-pool draft, not a final order list.
No new variants, AF3, SimpleFold, PyRosetta, FoldX, MD, or glycan modeling were run.

## Summary

| target | selected_count | main_count | control_anchor_count | canonical_duplicate_count | sequence_duplicate_count | variant_id_duplicate_count | hard_failure_count | top_seed | top_seed_count | top_seed_fraction | top_cluster | top_cluster_count | top_cluster_fraction | four_mut_count | four_mut_fraction | local_expansion_count | local_expansion_fraction | seed_only_count | seed_only_fraction | neutral_boundary_or_high_risk_count | neutral_boundary_or_high_risk_fraction | glycan_low_risk_claim_count | sdAb_complex_diagnostic_required_count | AG102H_AV105H_main_count | AY111H_containing_count | AY111H_containing_fraction | reasons |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Ab_sdAb | 15000 | 14980 | 20 | 0 | 0 | 0 | 0 | AQ100H | 4500 | 0.300000 | Ab_sdAb_hjc_00017 | 437 | 0.029133 | 679 | 0.045267 | 5716 | 0.381067 | 1241 | 0.082733 | 601 | 0.040067 | 0 | 15000 | 0 | 4914 | 0.327600 | all_per_target_15k_gates_pass |

## Evidence class distribution

| candidate_type | evidence_class | quality_tier | template_match_tier | count |
| --- | --- | --- | --- | --- |
| main_candidate | secondary_template_complex_weak | mpnn_favorable_pH_weak | B_medium | 5283 |
| main_candidate | secondary_template_complex_weak | supported | local_expansion_B | 2742 |
| main_candidate | secondary_template_complex_unchecked | supported | local_expansion_B | 2425 |
| main_candidate | secondary_template_complex_unchecked | mpnn_favorable_pH_weak | B_medium | 1430 |
| main_candidate | secondary_template_complex_unchecked | high_support | C_seed_only | 1008 |
| main_candidate | secondary_template_complex_unchecked | neutral_boundary_or_high_risk | B_medium | 565 |
| main_candidate | secondary_template_complex_weak | supported | local_expansion_A | 502 |
| main_candidate | secondary_template_complex_weak | high_support | B_medium | 310 |
| main_candidate | secondary_template_complex_unchecked | high_support | B_medium | 180 |
| main_candidate | low_priority_secondary_template | mpnn_favorable_pH_weak | C_seed_only | 138 |
| main_candidate | low_priority_secondary_template | high_support | B_medium | 108 |
| main_candidate | secondary_template_complex_unchecked | mpnn_favorable_pH_weak | C_seed_only | 55 |
| main_candidate | secondary_template_complex_unchecked | supported | local_expansion_A | 47 |
| main_candidate | secondary_template_complex_unchecked | supported | C_seed_only | 40 |
| main_candidate | secondary_template_complex_unchecked | neutral_boundary_or_high_risk | A_strong | 36 |
| main_candidate | secondary_template_complex_weak | mpnn_favorable_pH_weak | A_strong | 27 |
| main_candidate | low_priority_secondary_template | bank_reviewed | template_seed | 25 |
| control_anchor | control_anchor | control_anchor |  | 20 |
| main_candidate | secondary_template_complex_weak | bank_reviewed | template_seed | 20 |
| main_candidate | secondary_template_complex_unchecked | bank_reviewed | template_seed | 17 |
| main_candidate | low_priority_secondary_template | high_support | A_strong | 12 |
| main_candidate | boundary_representative_only | bank_reviewed | template_seed | 4 |
| main_candidate | secondary_template_complex_weak | high_support | A_strong | 3 |
| main_candidate | secondary_template_complex_unchecked | supported | B_medium | 2 |
| main_candidate | secondary_template_complex_unchecked | high_support | A_strong | 1 |

## Source distribution

| candidate_type | source_pool | quality_tier | template_match_tier | count |
| --- | --- | --- | --- | --- |
| main_candidate | tier1_ranked_production_pool | mpnn_favorable_pH_weak | B_medium | 6713 |
| main_candidate | constrained_local_expansion_v2 | supported | local_expansion_B | 5167 |
| main_candidate | constrained_local_expansion_v2 | supported | local_expansion_A | 549 |
| main_candidate | tier2_candidate_snapshot | high_support | C_seed_only | 525 |
| main_candidate | sdab_recovery_passlike_supplement | high_support | B_medium | 506 |
| main_candidate | tier2_candidate_snapshot | neutral_boundary_or_high_risk | B_medium | 399 |
| main_candidate | sdab_recovery_passlike_supplement | high_support | C_seed_only | 276 |
| main_candidate | tier1_ranked_production_pool | mpnn_favorable_pH_weak | C_seed_only | 193 |
| main_candidate | tier1_ranked_production_pool | high_support | C_seed_only | 176 |
| main_candidate | tier1_ranked_production_pool | neutral_boundary_or_high_risk | B_medium | 166 |
| main_candidate | tier2_candidate_snapshot | high_support | B_medium | 73 |
| main_candidate | tier2_candidate_bank | bank_reviewed | template_seed | 66 |
| main_candidate | tier2_candidate_snapshot | neutral_boundary_or_high_risk | A_strong | 35 |
| main_candidate | stage2a_candidate_list | high_support | C_seed_only | 31 |
| main_candidate | tier1_ranked_production_pool | supported | C_seed_only | 28 |
| main_candidate | tier1_ranked_production_pool | mpnn_favorable_pH_weak | A_strong | 27 |
| control_anchor | control_anchor_panel | control_anchor |  | 20 |
| main_candidate | sdab_recovery_passlike_supplement | high_support | A_strong | 16 |
| main_candidate | tier1_ranked_production_pool | high_support | B_medium | 15 |
| main_candidate | tier2_candidate_snapshot | supported | C_seed_only | 7 |
| main_candidate | stage2a_candidate_list | supported | C_seed_only | 5 |
| main_candidate | stage2a_candidate_list | high_support | B_medium | 4 |
| main_candidate | stage2a_candidate_list | supported | B_medium | 1 |
| main_candidate | tier1_ranked_production_pool | neutral_boundary_or_high_risk | A_strong | 1 |
| main_candidate | tier1_ranked_production_pool | supported | B_medium | 1 |

## Mutation count distribution

| mutation_count | count |
| --- | --- |
| 3 | 13638 |
| 4 | 679 |
| 2 | 676 |
| 1 | 6 |
| 0 | 1 |

## Seed distribution

| his_seed_set | count | fraction |
| --- | --- | --- |
| AQ100H | 4500 | 0.300000 |
| AD110H | 4500 | 0.300000 |
| AY111H | 4356 | 0.290400 |
| AQ100H;AD110H | 1082 | 0.072133 |
| AD110H;AY111H | 558 | 0.037200 |
| AG102H | 1 | 0.000067 |
| AV105H | 1 | 0.000067 |
| NA | 1 | 0.000067 |
| AE108H | 1 | 0.000067 |

## Cluster distribution

| near_duplicate_cluster_id | count | fraction |
| --- | --- | --- |
| Ab_sdAb_hjc_00017 | 437 | 0.029133 |
| Ab_sdAb_hjc_00012 | 436 | 0.029067 |
| Ab_sdAb_hjc_00005 | 345 | 0.023000 |
| Ab_sdAb_hjc_00003 | 235 | 0.015667 |
| Ab_sdAb_hjc_00006 | 163 | 0.010867 |
| sdAb_hjc_00005 | 161 | 0.010733 |
| sdAb_hjc_00004 | 75 | 0.005000 |
| Ab_sdAb_hjc_03380 | 75 | 0.005000 |
| Ab_sdAb_hjc_03435 | 71 | 0.004733 |
| sdAb_hjc_00008 | 64 | 0.004267 |
| Ab_sdAb_hjc_03437 | 62 | 0.004133 |
| sdAb_hjc_00001 | 61 | 0.004067 |
| Ab_sdAb_hjc_03529 | 60 | 0.004000 |
| Ab_sdAb_lex_701abc2be44e | 55 | 0.003667 |
| Ab_sdAb_hjc_03757 | 53 | 0.003533 |
| Ab_sdAb_hjc_03472 | 53 | 0.003533 |
| Ab_sdAb_hjc_03598 | 51 | 0.003400 |
| Ab_sdAb_hjc_03385 | 49 | 0.003267 |
| Ab_sdAb_hjc_03412 | 49 | 0.003267 |
| Ab_sdAb_lex_c9d2a02e2f9a | 49 | 0.003267 |

## Rejection / cap pressure summary

| reject_reason | count |
| --- | --- |
| seed_cap_full | 3007 |
| duplicate_with_control | 8 |

## Conservative labels

- Glycan remains unchecked; no low-risk glycan claim is made.
- sdAb remains secondary and complex-diagnostic-required for all rows.
- AG102H / AV105H are excluded from main candidates; if present, they are controls only.
- Manual review is required before final wet-lab order generation.
