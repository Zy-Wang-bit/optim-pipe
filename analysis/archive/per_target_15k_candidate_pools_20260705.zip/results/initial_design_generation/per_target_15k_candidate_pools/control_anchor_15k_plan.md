# Control anchor 15K plan

Controls / anchors are counted inside each target's 15K candidate pool.

| target | his_seed_set | mutation_count | sequence_reconstruction_status | count |
| --- | --- | --- | --- | --- |
| Ab_sdAb | AD110H | 2 | sequence_lookup_by_variant_id | 13 |
| Ab_1E62 | LD34H;LQ35H | 3 | sequence_lookup_by_variant_id | 9 |
| Ab_1E62 | LD34H;LY38H | 3 | sequence_lookup_by_variant_id | 2 |
| Ab_1E62 |  | 0 | sequence_lookup_by_variant_id | 1 |
| Ab_1E62 | LD34H | 1 | sequence_lookup_by_variant_id | 1 |
| Ab_1E62 | LK24H | 1 | sequence_lookup_by_variant_id | 1 |
| Ab_1E62 | LQ35H | 1 | sequence_lookup_by_variant_id | 1 |
| Ab_1E62 | LS26H | 1 | sequence_lookup_by_variant_id | 1 |
| Ab_1E62 | LS28H | 1 | sequence_lookup_by_variant_id | 1 |
| Ab_1E62 | LS33H | 1 | sequence_lookup_by_variant_id | 1 |
| Ab_1E62 | LY31H | 1 | sequence_lookup_by_variant_id | 1 |
| Ab_1E62 | LY38H | 1 | sequence_lookup_by_variant_id | 1 |
| Ab_sdAb |  | 0 | sequence_lookup_by_variant_id | 1 |
| Ab_sdAb | AD110H | 1 | sequence_lookup_by_variant_id | 1 |
| Ab_sdAb | AE108H | 1 | sequence_lookup_by_variant_id | 1 |
| Ab_sdAb | AG102H | 1 | sequence_lookup_by_variant_id | 1 |
| Ab_sdAb | AQ100H | 1 | sequence_lookup_by_variant_id | 1 |
| Ab_sdAb | AV105H | 1 | sequence_lookup_by_variant_id | 1 |
| Ab_sdAb | AY111H | 1 | sequence_lookup_by_variant_id | 1 |

Current explicit control panel contains 20 rows per target. No additional synthetic controls were invented in this step.
